<?php
    $con = mysqli_connect("sql786.main-hosting.eu","u535541061_klradio","Klradio@123","u535541061_klradio");
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>
